<!doctype html>
 <html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no"/>
	<link rel="stylesheet" href="<?php echo base_url();?>data/assets/skins/dropify/css/dropify.css">
   
    <link rel="icon" type="image/jpg" href="" sizes="32x32">
	 <link href="<?php echo base_url();?>data/css/font-awesome.min.css" rel="stylesheet" />
 <link href="http://netdna.bootstrapcdn.com/font-awesome/3.0.2/css/font-awesome.css" rel="stylesheet" />
 
    <title>Employee</title>
    <!-- additional styles for plugins -->
        <!-- weather icons -->
        <link rel="stylesheet" href="<?php echo base_url();?>data/bower_components/weather-icons/css/weather-icons.min.css" media="all">
        <!-- metrics graphics (charts) -->
        <link rel="stylesheet" href="<?php echo base_url();?>data/bower_components/metrics-graphics/dist/metricsgraphics.css">
        <!-- select2 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>data/bower_components/select2/select2.css">
        <!-- chartist -->
        <link rel="stylesheet" href="<?php echo base_url();?>data/bower_components/chartist/dist/chartist.min.css">
    <!-- uikit -->
    <link rel="stylesheet" href="<?php echo base_url();?>data/bower_components/uikit/css/uikit.almost-flat.min.css" media="all">

    <!-- flag icons -->
    <link rel="stylesheet" href="<?php echo base_url();?>data/assets/icons/flags/flags.min.css" media="all">
    <!-- style switcher -->
    <link rel="stylesheet" href="<?php echo base_url();?>data/assets/css/style_switcher.min.css" media="all">
        <!-- altair admin -->
    <link rel="stylesheet" href="<?php echo base_url();?>data/assets/css/main.min.css" media="all">
     <!-- jquery ui -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>data/assets/skins/jquery-ui/material/jquery-ui.min.css">
    
    <!-- themes -->
    <link rel="stylesheet" href="<?php echo base_url();?>data/assets/css/themes/themes_combined.min.css" media="all">
    
    <input type="hidden" value="<?php echo base_url(); ?>" id="base_url" />
</head>
<body class="disable_transitions sidebar_main_open sidebar_main_swipe">
    <!-- main header -->
    <header id="header_main">
        <div class="header_main_content">
            <nav class="uk-navbar">            
                <!-- main sidebar switch -->
                <a href="#" id="sidebar_main_toggle" class="sSwitch sSwitch_left">
                    <span class="sSwitchIcon"></span>
                </a>
                <!-- secondary sidebar switch -->
                       <div class="uk-navbar-flip">
                    <ul class="uk-navbar-nav user_actions">
                       
                    </ul>
                </div>
            </nav>
        </div>
        <div class="header_main_search_form">
            <i class="md-icon header_main_search_close material-icons">&#xE5CD;</i>
            <form class="uk-form uk-autocomplete" data-uk-autocomplete="{source:'data/search_data.json'}">
                <input type="text" class="header_main_search_input" />
                <button class="header_main_search_btn uk-button-link"><i class="md-icon material-icons">&#xE8B6;</i></button>
                <script type="text/autocomplete">
                    <ul class="uk-nav uk-nav-autocomplete uk-autocomplete-results">
                        {{~items}}
                        <li data-value="{{ $item.value }}">
                            <a href="{{ $item.url }}" class="needsclick">
                                {{ $item.value }}<br>
                                <span class="uk-text-muted uk-text-small">{{{ $item.text }}}</span>
                            </a>
                        </li>
                        {{/items}}
                    </ul>
                </script>
            </form>
        </div>
    </header>