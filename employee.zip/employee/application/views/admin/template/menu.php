<aside id="sidebar_main">
        <div class="sidebar_main_header">
            <div class="sidebar_logo">
                <a class="sSidebar_hide sidebar_logo_large">
                    <img class="logo_regular" src="" alt="Employee details" height="100%" width="100%"/>
                    <img class="logo_light" src="<?php echo base_url();?>data/assets/img/logo_main_white.png" alt="Magic Solver" height="100%" width="100%"/>
                </a>
                <a  class="sSidebar_show sidebar_logo_small">
                    <img class="logo_regular" src="<?php echo base_url();?>data/assets/img/logo_main_small.png" alt="" height="40" width="100"/>
                    <img class="logo_light" src="<?php echo base_url();?>data/assets/img/logo_main_small_light.png" alt="" height="40" width="100"/>
                </a>
            </div>
        </div>
        <div class="menu_section">
           <ul>
                <li <?php if($this->uri->segment(2)=="employee"){ echo "class='current_section'";} ?>title="Employee">
                    <a href="<?php echo base_url();?>employee">
                        <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                        <span class="menu_title">Employee</span>
                    </a>
                </li>
                <li <?php if($this->uri->segment(1)=="department"){ echo "class='current_section'";} ?> title="Department">
                    <a href="<?php echo base_url();?>department">
                         <span class="menu_icon"><i class="material-icons"></i></span>
                        <span class="menu_title">Department</span>
                    </a>
                </li>
                 
            </ul>
        </div>
    </aside><!-- main sidebar end -->