<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/menu'); ?>
    <div id="page_content">
        <div id="page_content_inner">
            <h3 class="heading_b uk-margin-bottom">View Employee </h3>
            <div class="md-card">
                <div class="md-card-content large-padding">
                 <?php if($this->session->flashdata('success')){?>                
                    		<div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <?php echo $this->session->flashdata('success');?>
                            </div>
						<?php } ?>
						<?php if($this->session->flashdata('fail')){?>
							 <div class="uk-alert uk-alert-danger" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <p><?php echo $this->session->flashdata('fail');?></p>
                            </div>
						<?php } ?>
                     <form id="form_validation" class="uk-form-stacked" method="post" action="<?php echo base_url(); ?>Employee/edit/<?php echo rtrim(base64_encode($info['0']['emp_id']),"=");?>" enctype="multipart/form-data">
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Name<span class="req">*</span></label>
                                    <input type="text" name="Employee_name" value="<?php echo $info['0']['emp_name'] ?>" class="md-input" onkeypress="return RestrictSpace()" id="Employee_name" required autocomplete="off" readonly="" /><span style="color: #dd0000"><?php echo form_error('Employee_name'); ?></span>
                                    <input type="hidden" name="Emp_id" value="<?php echo $info['0']['emp_id'] ?>"/>
                                </div>
                            </div>
                        </div>
                   		<div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Surname<span class="req">*</span></label>
                                    <input type="text" name="google_id" value="<?php echo $info['0']['emp_surname'] ?>" class="md-input"  required autocomplete="off" readonly=""/><span style="color: #dd0000"><?php echo form_error('google_id'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Address<span class="req">*</span></label>
                                    <input type="text" name="product_name" value="<?php echo $info['0']['emp_address'] ?>" class="md-input"  required autocomplete="off" readonly=""/><span style="color: #dd0000"><?php echo form_error('product_name'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Qualification<span class="req">*</span></label>
                                    <input type="text" name="description" value="<?php echo $info['0']['emp_qualification'] ?>" class="md-input"  required autocomplete="off" readonly=""/><span style="color: #dd0000"><?php echo form_error('description'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Contact No<span class="req">*</span></label>
                                    <input type="text" name="price" value="<?php echo $info['0']['emp_contact_no'] ?>" class="md-input"  required autocomplete="off" readonly=""/><span style="color: #dd0000"><?php echo form_error('price'); ?></span>
                                </div>
                            </div>
                        </div>
                         <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Department<span class="req">*</span></label>
                                    <input type="text" name="price" value="<?php echo $info['0']['emp_dept'] ?>" class="md-input"  required autocomplete="off" readonly=""/><span style="color: #dd0000"><?php echo form_error('price'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                            <a href="<?php echo base_url();?>Employee"> <button type="button" class="md-btn md-btn-primary" style="padding-right:10p !important;">Back</button></a>
                                <!--<button type="submit" class="md-btn md-btn-success">Add</button>-->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <script>
		function RestrictSpace() {
			if (event.keyCode == 32) {
				event.returnValue = false;
				return false;
			}
		}
	</script>
   
   
   <?php $this->load->view('admin/template/footer');?>
  