<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/menu'); ?>
<style>
#file{
color:green;
padding:5px;
border:1px dashed #123456;
background-color:#f9ffe5
}
	
#upload{
margin-left:45px
}

#noerror{
color:green;
text-align:left
}

#error{
color:red;
text-align:left
}

#img{
width:17px;
border:none;
height:17px;
margin-left:-20px;
margin-bottom:91px
}

.abcd{
text-align:center
}

.abcd img{
height:100px;
width:100px;
padding:5px;
border:1px solid #e8debd
}
</style>
    <div id="page_content">
        <div id="page_content_inner">
            <h3 class="heading_b uk-margin-bottom">Add Employee</h3>
            <div class="md-card">
                <div class="md-card-content large-padding">
                  <?php if($this->session->flashdata('success')){?>               
                    		<div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <?php echo $this->session->flashdata('success');?>
                            </div>
						<?php } ?>
						<?php if($this->session->flashdata('fail')){?>
							 <div class="uk-alert uk-alert-danger" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <p><?php echo $this->session->flashdata('fail');?></p>
                            </div>							
						<?php } ?>
                    <form id="form_validation" class="uk-form-stacked" method="post" action="<?php echo base_url(); ?>Employee/add" enctype="multipart/form-data">
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Name<span class="req">*</span></label>
                                    <input type="text" name="emp_name" value="<?php echo set_value('emp_name'); ?>" class="md-input" onkeypress="return RestrictSpace()" id="emp_name" required autocomplete="off" /><span style="color: #dd0000"><?php echo form_error('emp_name'); ?></span>
                                </div>
                            </div>
                        </div>
                   		<div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Surname<span class="req">*</span></label>
                                    <input type="text" name="emp_surname" value="<?php echo set_value('emp_surname'); ?>" class="md-input"  required autocomplete="off"/><span style="color: #dd0000"><?php echo form_error('emp_surname'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Address<span class="req">*</span></label>
                                    <textarea name="emp_address" class="md-input" required=""><?php echo set_value('emp_address'); ?></textarea>
                                    <span style="color: #dd0000"><?php echo form_error('emp_address'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Qualification<span class="req">*</span></label>
                                    <input type="text" name="emp_qualification" value="<?php echo set_value('emp_qualification'); ?>" class="md-input"  required autocomplete="off" /><span style="color: #dd0000"><?php echo form_error('emp_qualification'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Contact No<span class="req">*</span></label>
                                    <input type="text" name="emp_contact_no" value="<?php echo set_value('emp_contact_no'); ?>" class="md-input"  required autocomplete="off" maxlength="10" /><span style="color: #dd0000"><?php echo form_error('emp_contact_no'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Department<span class="req">*</span></label>
                                   <select name="dept_name" class="md-input">
                                   	<option value="">Select Department</option>
                                   	<?php
                                   	 foreach($dept as $val){ ?>
									 <option value="<?php echo $val['dept_id'];?>" <?php echo set_select('dept_name',$val['dept_id']); ?>><?php echo $val['dept_name']; ?></option>	
									<?php
									 }
                                   	 ?>
                                   </select>
                                   <span style="color: #dd0000"><?php echo form_error('dept_name'); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                            <a href="<?php echo base_url();?>Employee"> <button type="button" class="md-btn md-btn-primary" style="padding-right:10p !important;">Back</button></a>
                                <button type="submit" class="md-btn md-btn-success">Add</button>
                            </div>
                        </div>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
    <script>
		function RestrictSpace() {
			if (event.keyCode == 32) {
				event.returnValue = false;
				return false;
			}
		}
	</script>
   
   <?php $this->load->view('admin/template/footer');?>