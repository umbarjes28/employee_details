<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/menu'); ?>
<style>
	
	
#file{

color:green;

padding:5px;

border:1px dashed #123456;

background-color:#f9ffe5

}
	
#upload{

margin-left:45px

}

#noerror{

color:green;

text-align:left

}

#error{

color:red;

text-align:left

}

#img{

width:17px;

border:none;

height:17px;

margin-left:-20px;

margin-bottom:91px

}

.abcd{

text-align:center

}

.abcd img{

height:100px;

width:100px;

padding:5px;

border:1px solid #e8debd

}
</style>
     <div id="page_content">
        <div id="page_content_inner">
            <h4 class="heading_a uk-margin-bottom">Employee Management</h4>
            <div class="md-card uk-margin-medium-bottom">
                <div class="md-card-content">
                <?php if($this->session->flashdata('success')){?>                                   
                    		<div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <?php echo $this->session->flashdata('success');?>
                            </div>
						<?php } ?>

						<?php if($this->session->flashdata('fail')){?>
							 <div class="uk-alert uk-alert-danger" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <p><?php echo $this->session->flashdata('fail');?></p>
                            </div>
							
						<?php } ?>
                    <div class="dt_colVis_buttons"></div>
                      <div class="uk-grid">
                            <div class="uk-width-1-1">
                        <a href="<?php echo base_url();?>employee/add"><button style="float: right;" type="button" class="md-btn md-btn-primary">Add New</button></a>
                            </div>
                        </div>
                      <form  action="<?php echo base_url();?>employee/multiselect_action" method="post" name="myform" id="myform">    
                        
                    <table id="dt_tableExport" class="uk-table uk-table-nowrap table_check" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                         <th class=" uk-text-center small_col" style="padding-right:5px !important;"><input type="checkbox" data-md-icheck class="check_all"></th>
                            <th>employee Name</th>
                            <th>employee Surname</th>
                            <th >Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
                            if(!empty($info))
                            {
								foreach($info as $val)
								{
								?>
                        <tr>
                         <td class=" uk-text-center small_col" style="padding-right:5px !important;"><input type="checkbox" data-md-icheck class="check_row"  name="checkall[<?php echo $val['emp_id'];?>]" id="check"></td>
                            <td><?php echo $val['emp_name'];?></td>
                            <td><?php echo $val['emp_surname'];?></td>
                           <td>
                            <a href="<?php echo base_url();?>employee/view/<?php echo rtrim(base64_encode($val['emp_id']),"=");?>" class="md-fab md-fab-primary md-fab-small"><i class="material-icons"></i></a>&nbsp;&nbsp;
                           
                            <a href="<?php echo base_url();?>employee/edit/<?php echo rtrim(base64_encode($val['emp_id']),"=");?>" class="md-fab md-fab-success md-fab-small"><i class="material-icons">&#xE254;</i></a>&nbsp;&nbsp;
                            
                            
                         </td>
                        </tr>
                         <?php
							}
								}
                    		?>
                        </tbody>
                    </table>
					 
					 </form>  
                </div>
            </div>

        </div>
    </div>

    <!-- google web fonts -->
   <?php $this->load->view('admin/template/footer');?>
   
<script>
	function change_status(catid)
	{
		var done = confirm("Are you sure, you want to change the status?");
		if(done == true)
		{
			var pageurl_new = $("#base_url").val() +'employee/change_status/'+catid;
			window.location.href = pageurl_new;
		}
		else{
				return false;
			}
	}

</script>
<script>
    function confirmDelete()
	{
	return confirm("Do you want to delete this record");
	}
</script>
 <script>
      $(function () {
        
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": true,
          "ordering": false,
          "info": true,
          "autoWidth": false
          //"order": [[ 0, "desc" ]],
        });
</script>

<script>
	
$('.selectall').click(function() {
    $(this.form.elements).filter(':checkbox').prop('checked', this.checked);
});

</script>