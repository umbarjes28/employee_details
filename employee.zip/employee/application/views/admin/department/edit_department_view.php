<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/menu'); ?>
    <div id="page_content">
        <div id="page_content_inner">
            <h3 class="heading_b uk-margin-bottom">Edit Department View</h3>
            <div class="md-card">
                <div class="md-card-content large-padding">
                 <?php if($this->session->flashdata('success')){?>                
                    		<div class="uk-alert uk-alert-success" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <?php echo $this->session->flashdata('success');?>
                            </div>
						<?php } ?>
						<?php if($this->session->flashdata('fail')){?>
							 <div class="uk-alert uk-alert-danger" data-uk-alert>
                                <a href="#" class="uk-alert-close uk-close"></a>
                                <p><?php echo $this->session->flashdata('fail');?></p>
                            </div>
						<?php } ?>
                     <form id="form_validation" class="uk-form-stacked" method="post" action="<?php echo base_url(); ?>Department/edit/<?php echo rtrim(base64_encode($info['0']['dept_id']),"=");?>" enctype="multipart/form-data">
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-2">
                                <div class="parsley-row">
                                    <label for="fullname">Name<span class="req">*</span></label>
                                    <input type="text" name="dept_name" value="<?php echo $info['0']['dept_name'] ?>" class="md-input" onkeypress="return RestrictSpace()" id="dept_name" required autocomplete="off" /><span style="color: #dd0000"><?php echo form_error('dept_name'); ?></span>
                                    <input type="hidden" name="dept_id" value="<?php echo $info['0']['dept_id'] ?>"/>
                                </div>
                            </div>
                        </div>
                   		
                        <div class="uk-grid">
                            <div class="uk-width-1-1">
                            <a href="<?php echo base_url();?>Department"> <button type="button" class="md-btn md-btn-primary" style="padding-right:10p !important;">Back</button></a>
                                <button type="submit" class="md-btn md-btn-success">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <script>
		function RestrictSpace() {
			if (event.keyCode == 32) {
				event.returnValue = false;
				return false;
			}
		}
	</script>
   
   
   <?php $this->load->view('admin/template/footer');?>
  