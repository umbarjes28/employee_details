<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('employee_model');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('security');
	}

	public function index()
	{ 
		
		$data['info']=$this->employee_model->get_data();
	  	$this->load->view('admin/employee/manage_employee_view',$data);
	}

	public function view($f_id)
	{
		
		$id = base64_decode($f_id);
		$data['info']=$this->employee_model->view($id);
		$this->load->view('admin/employee/employee_view',$data);
    }

	public function add()
	{
	
		$this->form_validation->set_rules('emp_name','Name','trim|xss_clean|required|alpha');
		$this->form_validation->set_rules('emp_surname','Surname','trim|xss_clean|required|alpha');
		$this->form_validation->set_rules('emp_address','Address','trim|xss_clean|required');
		$this->form_validation->set_rules('emp_qualification','Qualification','trim|xss_clean|required');
		$this->form_validation->set_rules('emp_contact_no','Contact Number','trim|xss_clean|required|integer|exact_length[10]|is_unique[employee_details.emp_contact_no]');
		$this->form_validation->set_rules('dept_name','Department Name','trim|xss_clean|required');
        if($this->form_validation->run())
		{
					$data=array(
							'emp_name'=>$_POST['emp_name'],
							'emp_surname'=>$_POST['emp_surname'],
							'emp_address'=>$_POST['emp_address'],
							'emp_qualification'=>$_POST['emp_qualification'],
							'emp_contact_no'=>$_POST['emp_contact_no'],
							'emp_dept'=>$_POST['dept_name'],
							'created'=>date('Y-m-d H:i:s')
						    ); 
		    	$res=$this->employee_model->add($data);
				if($res > 0)
		 		{
			 		$this->session->set_flashdata('success','Added successfully. Add another employee');
	     			redirect('employee/add');
	         	}
			 	else
	 	  		{
					 $this->session->set_flashdata('fail','Fail to Add');
					redirect('employee');

 	  		}
		}
		else
        {
        	$data['dept']=$this->employee_model->get_all_dept();
    		$this->load->view('admin/employee/add_employee_view',$data);
		}

    }
	
	public function edit($f_id)
	{
		
		$id = base64_decode($f_id);
		$this->form_validation->set_rules('emp_name','Name','trim|xss_clean|required|alpha');
		$this->form_validation->set_rules('emp_surname','Surname','trim|xss_clean|required|alpha');
		$this->form_validation->set_rules('emp_address','Address','trim|xss_clean|required');
		$this->form_validation->set_rules('emp_qualification','Qualification','trim|xss_clean|required');
		$this->form_validation->set_rules('emp_contact_no','Contact Number','trim|xss_clean|required|integer|exact_length[10]');
		$this->form_validation->set_rules('dept_name','Department Name','trim|xss_clean|required');
        if($this->form_validation->run())
		{
					$data=array(
							'emp_name'=>$_POST['emp_name'],
							'emp_surname'=>$_POST['emp_surname'],
							'emp_address'=>$_POST['emp_address'],
							'emp_qualification'=>$_POST['emp_qualification'],
							'emp_contact_no'=>$_POST['emp_contact_no'],
							'emp_dept'=>$_POST['dept_name'],
						    ); 
		    	$res=$this->employee_model->update_employee($data,$id);
				if($res > 0)
		 		{
			 		$this->session->set_flashdata('success','Record Updated Successfully');
	     			redirect('employee');
	         	}
			 	else
	 	  		{
					 $this->session->set_flashdata('fail','Fail to Update');
					redirect('employee');

 	  		}
		}
		else
        {
        	$data['dept']=$this->employee_model->get_all_dept();
        	$data['info']=$this->employee_model->edit($id);
    		$this->load->view('admin/employee/edit_employee_view',$data);
		}

    }
	
}	

	

