<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Department extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('department_model');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('security');
	}

	public function index()
	{ 
		
		$data['info']=$this->department_model->get_data();
	  	$this->load->view('admin/department/manage_department_view',$data);
	}
	
	
	public function view($f_id)
	{
		
		$id = base64_decode($f_id);
		$data['info']=$this->department_model->view($id);
		$this->load->view('admin/department/department_view',$data);
    }

	public function add()
	{
	
		$this->form_validation->set_rules('dept_name','Name','trim|xss_clean|required|alpha|is_unique[department.dept_name]');
		
        if($this->form_validation->run())
		{
					$data=array(
							'dept_name'=>$_POST['dept_name'],
							'created'=>date('Y-m-d H:i:s')
						    ); 
						//print_r($data);die;
		    	$res=$this->department_model->add($data);
				if($res > 0)
		 		{
			 		$this->session->set_flashdata('success','Added successfully. Add another department');
	     			redirect('department/add');
	         	}
			 	else
	 	  		{
					 $this->session->set_flashdata('fail','Fail to Add');
					redirect('department');

 	  		}
		}
		else
        {

    		$this->load->view('admin/department/add_department_view');
		}

    }
	
	public function edit($f_id)
	{
		
		$id = base64_decode($f_id);
		$this->form_validation->set_rules('dept_name','Name','trim|xss_clean|required|alpha');
        if($this->form_validation->run())
		{
					$data=array(
							'dept_name'=>$_POST['dept_name'],
						    ); 
						//print_r($data);die;
		    	$res=$this->department_model->update_department($data,$id);
				if($res > 0)
		 		{
			 		$this->session->set_flashdata('success','Record Updated Successfully');
	     			redirect('department');
	         	}
			 	else
	 	  		{
					 $this->session->set_flashdata('fail','Fail to Update');
					redirect('department');

 	  		}
		}
		else
        {
        	$data['dept']=$this->department_model->get_all_dept();
        	$data['info']=$this->department_model->edit($id);
        	//print_r($data);
    		$this->load->view('admin/department/edit_department_view',$data);
		}

    }
	
	
	public function delete($id)
	{  
		$res=$this->department_model->delete($id);	
	    if($res > 0)
		{
	    	$this->session->set_flashdata('success','Deleted successfully');
			redirect('department');
		}
	  } 

	
	
}	

	

