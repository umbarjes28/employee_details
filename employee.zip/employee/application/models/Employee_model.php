<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Employee_model extends CI_Model
{
     function __construct()
     
    {
	    parent::__construct();
	    $this->load->database();
    }

    public function add($data)
   	{
		 $this->db->insert('employee_details',$data);
		 return $this->db->insert_id();
   	}

	public function get_data()
    {
   	 	$this->db->select('*');
    	$this->db->from('employee_details');
    	$this->db->order_by("created",'desc');
		return $this->db->get()->result_array();    	

    }
    
    public function get_all_dept()
    {
		$this->db->select('*');
		$this->db->from('department');
		return $this->db->get()->result_array();
	}

	public function edit($id)

    {
   		$this->db->select('*');
   		$this->db->from('employee_details ');
   		$this->db->where('emp_id',$id);
		return $this->db->get()->result_array();   

    }

	public function update_employee($data,$id)
    {
   		$this->db->where('emp_id',$id);
		return $this->db->update('employee_details',$data);

    }

	public function view($id)
   	{
   		$this->db->select('e.*,d.dept_name as emp_dept');
   		$this->db->from('employee_details e');
   		$this->db->join('department d','d.dept_id=e.emp_dept','left');
   		$this->db->where('e.emp_id',$id);
		return $this->db->get()->result_array();   
   	} 

}