<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Department_model extends CI_Model
{
     function __construct()
     
    {
	    parent::__construct();
	    $this->load->database();
    }

    public function add($data)
   	{
		 $this->db->insert('department',$data);
		 return $this->db->insert_id();
   	}

	public function get_data()
    {
   	 	$this->db->select('*');
    	$this->db->from('department');
    	$this->db->order_by("created",'desc');
		return $this->db->get()->result_array();    	

    }
    
	public function edit($id)

    {
   		$this->db->select('*');
   		$this->db->from('department ');
   		$this->db->where('dept_id',$id);
		return $this->db->get()->result_array();   

    }

	public function update_department($data,$id)
    {
   		$this->db->where('dept_id',$id);
		return $this->db->update('department',$data);

    }

	public function view($id)
   	{
   		$this->db->select('e.*');
   		$this->db->from('department e');
   		$this->db->where('e.dept_id',$id);
		return $this->db->get()->result_array();   
   	} 

	public function delete($id)
    {
	    $this->db->where('dept_id',$id);
        return $this->db->delete('department');
	} 
	 public function get_all_dept()
    {
		$this->db->select('*');
		$this->db->from('department');
		return $this->db->get()->result_array();
	}
}